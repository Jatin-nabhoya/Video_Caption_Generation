# Worst-case analysis (Fine-tuned models)

## 1. `nTUONeDqhdk_10_15` - class: People & Daily life - mean CIDEr 0.7
**Reference captions (first 3):** a baby is on football dress | a baby is walking and falls over | a boy playing goalie falls down
**Clip-level reasons:** annotators disagree (low reference consensus); rare concept in training captions

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a man is swinging from a chain in a garage | 0.0 | Action error; Hallucinated details | swinging chain garage |
| GIT | a woman is dancing | 0.0 | Gender / age confusion; Action error | dancing |
| BLIP-2 | a man is playing a flute | 2.7 | Hallucinated details | flute |
| Qwen2.5-VL | a man is beating a woman | 0.0 | Action error | beating |

## 2. `h0JvF9vpqx8_36_42` - class: People & Daily life - mean CIDEr 0.8
**Reference captions (first 3):** a girl falls | a girl is falling down a mushroom staircase | a girl is falling down
**Clip-level reasons:** annotators disagree (low reference consensus)

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a actor is smoking in the film sequence | 0.0 | Object / subject error; Action error; Hallucinated details | actor smoking film sequence |
| GIT | a man is dancing | 0.0 | Gender / age confusion; Action error | dancing |
| BLIP-2 | a man is playing a guitar | 3.2 | Gender / age confusion; Hallucinated details | guitar |
| Qwen2.5-VL | a man is dancing | 0.0 | Gender / age confusion; Action error | dancing |

## 3. `f_GnkweYzzI_35_41` - class: People & Daily life - mean CIDEr 0.9
**Reference captions (first 3):** a man throw a brick at a man on the ground | a man gets hit in the head with a brick | a man on a roof is tossing bricks to a man on the ground when the man on the ground is distracted and one of the flying bricks hits him in the head
**Clip-level reasons:** annotators disagree (low reference consensus); rare concept in training captions

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | two men are pushing wheelbarrows | 0.5 | Action error; Hallucinated details; Counting error | two pushing wheelbarrows |
| GIT | a man is pushing a cart | 1.2 | Action error; Hallucinated details | pushing cart |
| BLIP-2 | a man is pushing a wheelbarrow | 1.0 | Action error; Hallucinated details | pushing wheelbarrow |
| Qwen2.5-VL | a man is pushing a wheelbarrow | 1.0 | Action error; Hallucinated details | pushing wheelbarrow |

## 4. `xxHx6s_DbUo_240_248` - class: Cooking & Food - mean CIDEr 1.1
**Reference captions (first 3):** a man hits clay pots of water suspended from ropes with his hands and feet and breaks them | a man breaks hanging pots | a man is kicking pots
**Clip-level reasons:** fast motion / camera shake

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a scene from the rocky 3 movie where rocky is in training | 0.0 | Object / subject error; Action error; Hallucinated details | scene rocky movie where rocky training |
| GIT | a man is spinning a ball on a rope | 1.2 | Action error; Hallucinated details | spinning ball |
| BLIP-2 | a man is boxing | 1.8 | Action error | boxing |
| Qwen2.5-VL | a man is swinging on a rope | 1.4 | Action error | swinging |

## 5. `vE1gvaM3iAs_39_46` - class: People & Daily life - mean CIDEr 1.4
**Reference captions (first 3):** a gloved individual wipes off a dvd | a man cleans a compact disc | a man cleans a dvd
**Clip-level reasons:** annotators disagree (low reference consensus); rare concept in training captions

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a person is preparing item | 1.8 | Action error; Hallucinated details; Too generic | preparing item |
| GIT | a man is taking something out of a plastic container | 0.9 | Hallucinated details | taking plastic container |
| BLIP-2 | a man is preparing food | 1.9 | Action error; Hallucinated details | preparing food |
| Qwen2.5-VL | a man is putting toothpaste on a toothbrush | 1.0 | Action error; Hallucinated details | putting toothbrush |

## 6. `lFdg5CWMTt0_24_28` - class: People & Daily life - mean CIDEr 1.5
**Reference captions (first 3):** the man used a hammer to hit his hand | a man hammering something hits his thumb and kicks out at the wooden steps | a man hits his thumb while hammering
**Clip-level reasons:** no clip-level red flag - model-side errors

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a man karate chops several cinder blocks | 0.6 | Hallucinated details | karate chops several cinder blocks |
| GIT | a man is walking with a sword | 2.7 | Action error; Hallucinated details | walking sword |
| BLIP-2 | a man is breaking a wooden box | 1.5 | Action error; Hallucinated details | breaking box |
| Qwen2.5-VL | a man is trying to open a box | 1.3 | Action error; Hallucinated details | trying open box |

## 7. `wFX6bXLbHW4_83_90` - class: Sports & Exercise - mean CIDEr 1.6
**Reference captions (first 3):** a man in a black cape causes a policeman to disappear and continues to walk after being shot several times by another man | a man shoots a man | a man is being shot
**Clip-level reasons:** annotators disagree (low reference consensus); dark footage

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a man is selling a smoking barrels | 1.4 | Action error; Hallucinated details | selling smoking barrels |
| GIT | three men are dancing | 3.1 | Action error; Hallucinated details; Counting error | three dancing |
| BLIP-2 | a group of people are having a party | 0.6 | Action error; Hallucinated details; Too generic; Counting error | party |
| Qwen2.5-VL | a man is lighting candles on a table | 1.4 | Action error; Hallucinated details | lighting candles table |

## 8. `qIk_Dz5XE5E_104_109` - class: People & Daily life - mean CIDEr 1.8
**Reference captions (first 3):** a mannequin is tossed away | two men throw a mannequin over a cliff while a woman in a nurses cap watches | people throw a mannequin off a cliff
**Clip-level reasons:** annotators disagree (low reference consensus); rare concept in training captions; fast motion / camera shake

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | it s a scene from hollywood movie | 0.4 | Object / subject error; Hallucinated details | scene hollywood movie |
| GIT | a man is pushing a car | 0.1 | Action error | pushing |
| BLIP-2 | a man is falling from a car | 1.1 | Action error | falling |
| Qwen2.5-VL | a man is running down a hill | 5.4 | Action error | running |
