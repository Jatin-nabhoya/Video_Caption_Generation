# Best-case analysis (Fine-tuned models)

## 1. `yU5sxW9bErQ_0_17` - class: Animals - mean CIDEr 486.3
**Reference captions (first 3):** a man is riding a horse down the street | a man is riding a horse down the street | a man is riding a horse on a paved road
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive animals content

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a man is riding on te horse | 204.5 | - | - |
| GIT | a man is riding a horse | 580.3 | - | - |
| BLIP-2 | a man is riding a horse | 580.3 | - | - |
| Qwen2.5-VL | a man is riding a horse | 580.3 | - | - |

## 2. `gHzws6FpuNE_10_12` - class: Vehicles - mean CIDEr 466.1
**Reference captions (first 3):** a car is driven | a car is shown driving through a parking lot | a man drives a car
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive vehicles content; stable camera, single clear action

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | one man is driving a car | 416.0 | - | one |
| GIT | a man is driving a car | 482.8 | - | - |
| BLIP-2 | a man is driving a car | 482.8 | - | - |
| Qwen2.5-VL | a man is driving a car | 482.8 | - | - |

## 3. `inLBPVG8oEU_18_24` - class: Music & Dance - mean CIDEr 444.6
**Reference captions (first 3):** a young man is dancing alone | a man is dancing | a man is dancing on a stage
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive music & dance content; stable camera, single clear action

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | the man is dancing in front of an audience | 157.4 | Hallucinated details | audience |
| GIT | a man is dancing | 540.4 | - | - |
| BLIP-2 | a man is dancing | 540.4 | - | - |
| Qwen2.5-VL | a man is dancing | 540.4 | - | - |

## 4. `fjDvKHkmxs0_119_126` - class: Vehicles - mean CIDEr 437.7
**Reference captions (first 3):** a man driving a car | a man drives a car | a man drives around a town
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive vehicles content

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | the man is drive the car on the road and seeing the place | 26.4 | Action error; Hallucinated details | road seeing place |
| GIT | a man is driving a car | 574.9 | - | - |
| BLIP-2 | a man is driving a car | 574.9 | - | - |
| Qwen2.5-VL | a man is driving a car | 574.9 | - | - |

## 5. `u4kMN1jamdM_10_20` - class: Animals - mean CIDEr 406.6
**Reference captions (first 3):** a woman riding a horse on the beach | a girl is lead on a white horse at the beach | a woman is having a ride on the back of a white horse by the beachside
**Clip-level reasons:** annotators agree (high consensus); distinctive animals content; stable camera, single clear action

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a woman is riding a white horse by the beachside | 208.6 | - | - |
| GIT | a woman is riding a horse | 485.3 | - | - |
| BLIP-2 | a woman is riding a horse | 485.3 | - | - |
| Qwen2.5-VL | a woman is riding a horse on the beach | 447.1 | - | - |

## 6. `v4_AzQSnmY4_40_55` - class: Animals - mean CIDEr 392.5
**Reference captions (first 3):** a woman gallops on a horse | a person rides a horse | a woman is riding a horse along a road
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive animals content

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a woman rides dressage | 27.6 | Hallucinated details | dressage |
| GIT | a woman is riding a horse | 514.2 | - | - |
| BLIP-2 | a woman is riding a horse | 514.2 | - | - |
| Qwen2.5-VL | a woman is riding a horse | 514.2 | - | - |

## 7. `ptHkvYrH9fY_2_10` - class: Music & Dance - mean CIDEr 387.9
**Reference captions (first 3):** a man playing a flute | a boy is playing a flute | a boy is playing flute
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive music & dance content; stable camera, single clear action

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | the played his wooden flute | 197.5 | Object / subject error | - |
| GIT | a man is playing a flute | 451.4 | - | - |
| BLIP-2 | a man is playing a flute | 451.4 | - | - |
| Qwen2.5-VL | a man is playing a flute | 451.4 | - | - |

## 8. `j7xz1nos-xc_10_20` - class: Music & Dance - mean CIDEr 384.1
**Reference captions (first 3):** a boy is playing a grand piano | a boy is playing a piano | a little boy is playing piano
**Clip-level reasons:** annotators agree (high consensus); very common concept in training data; distinctive music & dance content; stable camera, single clear action

| Model | Prediction | CIDEr | Diagnosed problems | Unsupported words |
|---|---|---:|---|---|
| CLIP4Clip | a boy is playing paino | 130.6 | Hallucinated details | paino |
| GIT | a boy is playing a piano | 478.7 | - | - |
| BLIP-2 | a boy is playing a piano | 478.7 | - | - |
| Qwen2.5-VL | a boy is playing the piano | 448.3 | - | - |
