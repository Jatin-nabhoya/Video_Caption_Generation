# Model-specific wins and failures

- **CLIP4Clip FAILS** `fjDvKHkmxs0_119_126`: CLIP4Clip CIDEr 26.4 vs others 574.9. CLIP4Clip: "the man is drive the car on the road and seeing the place" | ref: "a man driving a car"
- **CLIP4Clip WINS** `puineN1UMto_25_29`: CLIP4Clip CIDEr 496.9 vs others 258.1. CLIP4Clip: "a squirrel is dancing" | ref: "a squirrel is hopping back and forth in the grass on it s hind legs"
- **GIT FAILS** `p6T3XrnYtFk_4_13`: GIT CIDEr 0.0 vs others 386.4. GIT: "a donkey is eating" | ref: "a goat is walking about"
- **GIT WINS** `xxHx6s_DbUo_82_86`: GIT CIDEr 453.6 vs others 121.0. GIT: "a man is climbing a rope" | ref: "a shirtless man is climbing up a rope suspended from the ceiling"
- **BLIP-2 FAILS** `hJFBXHtxKIc_317_322`: BLIP-2 CIDEr 115.2 vs others 232.5. BLIP-2: "a man is eating a bowl of chili" | ref: "a man is eating spaghetti from a large bowl while standing"
- **BLIP-2 WINS** `xxHx6s_DbUo_162_165`: BLIP-2 CIDEr 466.6 vs others 4.0. BLIP-2: "a man is running" | ref: "a man is running"
- **Qwen2.5-VL FAILS** `puineN1UMto_25_29`: Qwen2.5-VL CIDEr 24.9 vs others 415.4. Qwen2.5-VL: "a cat is playing in the grass" | ref: "a squirrel is hopping back and forth in the grass on it s hind legs"
- **Qwen2.5-VL WINS** `p6T3XrnYtFk_4_13`: Qwen2.5-VL CIDEr 564.9 vs others 198.1. Qwen2.5-VL: "a goat is walking" | ref: "a goat is walking about"
