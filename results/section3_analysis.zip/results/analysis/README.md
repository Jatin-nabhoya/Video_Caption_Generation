# Section 3 - Experimental analysis

Example picks use the **Fine-tuned** models. Classes are keyword buckets built from the reference captions (MSVD has no labels).

## Overall

|                              |   BLEU-4 |   METEOR |   ROUGE-L |   CIDEr |
|:-----------------------------|---------:|---------:|----------:|--------:|
| ('CLIP4Clip', 'Zero-shot')   |    17.48 |    25.32 |     50.79 |   39.36 |
| ('CLIP4Clip', 'Fine-tuned')  |    22.85 |    26.96 |     54.15 |   45.89 |
| ('GIT', 'Zero-shot')         |    18.71 |    23.20 |     47.73 |   39.85 |
| ('GIT', 'Fine-tuned')        |    54.25 |    38.00 |     75.10 |  101.27 |
| ('BLIP-2', 'Zero-shot')      |    29.12 |    32.96 |     58.22 |   49.07 |
| ('BLIP-2', 'Fine-tuned')     |    75.47 |    49.88 |     86.99 |  178.34 |
| ('Qwen2.5-VL', 'Zero-shot')  |    42.54 |    36.89 |     68.94 |   81.88 |
| ('Qwen2.5-VL', 'Fine-tuned') |    67.98 |    44.65 |     82.13 |  146.95 |

## Class sizes

| class               |   videos |
|:--------------------|---------:|
| Cooking & Food      |   173.00 |
| People & Daily life |   146.00 |
| Animals             |   141.00 |
| Sports & Exercise   |    80.00 |
| Music & Dance       |    72.00 |
| Vehicles            |    54.00 |
| Other               |     4.00 |

## Per-class CIDEr (Fine-tuned)

| Class               |   BLIP-2 |   CLIP4Clip |    GIT |   Qwen2.5-VL |
|:--------------------|---------:|------------:|-------:|-------------:|
| ALL                 |   178.34 |       45.89 | 101.27 |       146.95 |
| Animals             |   210.55 |       62.61 | 118.98 |       179.79 |
| Cooking & Food      |   149.78 |       34.99 |  77.23 |       118.32 |
| Music & Dance       |   296.56 |       76.74 | 218.04 |       252.44 |
| Other               |    31.85 |       32.03 |   8.81 |         2.44 |
| People & Daily life |   145.67 |       33.81 |  63.38 |       113.13 |
| Sports & Exercise   |   147.88 |       36.64 |  67.86 |       110.43 |
| Vehicles            |   172.44 |       43.45 | 135.17 |       168.48 |

## Error taxonomy (% of failed captions)

|                      |   Object / subject error |   Gender / age confusion |   Action error |   Hallucinated details |   Verbose / style mismatch |   Too generic |   Counting error |   Wording only (meaning OK) |
|:---------------------|-------------------------:|-------------------------:|---------------:|-----------------------:|---------------------------:|--------------:|-----------------:|----------------------------:|
| ('BLIP-2', 'FT')     |                        4 |                        5 |             33 |                      2 |                          0 |             3 |                2 |                          51 |
| ('BLIP-2', 'ZS')     |                       15 |                        2 |             25 |                     42 |                          5 |             0 |                1 |                          10 |
| ('CLIP4Clip', 'FT')  |                       31 |                        3 |             24 |                     24 |                          0 |             3 |                1 |                          15 |
| ('CLIP4Clip', 'ZS')  |                       29 |                        7 |             22 |                     37 |                          0 |             1 |                0 |                           4 |
| ('GIT', 'FT')        |                       13 |                       12 |             48 |                      6 |                          0 |             3 |                1 |                          18 |
| ('GIT', 'ZS')        |                       38 |                        4 |             16 |                     27 |                          0 |             4 |                1 |                          10 |
| ('Qwen2.5-VL', 'FT') |                       10 |                       13 |             41 |                      6 |                          0 |             3 |                4 |                          23 |
| ('Qwen2.5-VL', 'ZS') |                       16 |                        6 |             33 |                     30 |                          1 |             0 |                2 |                          12 |

## Caption behaviour

|                      |   mean_len |   unsupported_words_per_cap |   exact_ref_match_pct |   copied_train_caption_pct |   failure_rate_pct |   vocab_size |
|:---------------------|-----------:|----------------------------:|----------------------:|---------------------------:|-------------------:|-------------:|
| ('BLIP-2', 'FT')     |       6.53 |                        0.27 |                 40.90 |                      40.75 |              25.07 |       526.00 |
| ('BLIP-2', 'ZS')     |      13.00 |                        2.20 |                  0.30 |                       0.15 |              45.67 |       970.00 |
| ('CLIP4Clip', 'FT')  |       7.56 |                        2.01 |                  1.49 |                     100.00 |              57.01 |      1236.00 |
| ('CLIP4Clip', 'ZS')  |       9.27 |                        2.92 |                  1.04 |                     100.00 |              61.04 |      1271.00 |
| ('GIT', 'FT')        |       6.31 |                        0.84 |                 20.15 |                      56.57 |              37.61 |       392.00 |
| ('GIT', 'ZS')        |       8.36 |                        1.96 |                  0.15 |                       0.45 |              58.96 |       657.00 |
| ('Qwen2.5-VL', 'FT') |       6.40 |                        0.50 |                 32.24 |                      41.94 |              25.07 |       504.00 |
| ('Qwen2.5-VL', 'ZS') |      10.27 |                        1.58 |                  4.33 |                       3.58 |              33.88 |       878.00 |

## Difficulty factors (Spearman rho with CIDEr)

| Factor         |   BLIP-2 |   CLIP4Clip |   GIT |   Qwen2.5-VL |
|:---------------|---------:|------------:|------:|-------------:|
| brightness     |    -0.00 |        0.07 |  0.04 |         0.02 |
| concept_rarity |    -0.17 |       -0.01 | -0.29 |        -0.17 |
| duration_s     |     0.06 |        0.14 |  0.09 |         0.15 |
| motion         |    -0.14 |       -0.13 | -0.13 |        -0.15 |
| ref_consensus  |     0.59 |        0.23 |  0.31 |         0.47 |
| ref_len        |    -0.23 |       -0.08 | -0.17 |        -0.16 |

## Worst 10% vs best 10% of clips

|                |   worst 10% |   all videos |   best 10% |
|:---------------|------------:|-------------:|-----------:|
| ref_consensus  |        0.19 |         0.26 |       0.45 |
| concept_rarity |        4.53 |         4.43 |       3.70 |
| duration_s     |        8.81 |        10.11 |      10.15 |
| brightness     |      111.68 |       109.80 |     113.34 |
| motion         |       35.62 |        30.39 |      24.67 |
| ref_len        |        6.90 |         6.53 |       5.98 |


| class               |   worst 10% (%) |   all (%) |   best 10% (%) |
|:--------------------|----------------:|----------:|---------------:|
| Animals             |               9 |        21 |             30 |
| Cooking & Food      |              19 |        26 |             10 |
| Music & Dance       |               1 |        11 |             39 |
| Other               |               3 |         1 |              0 |
| People & Daily life |              46 |        22 |             10 |
| Sports & Exercise   |              15 |        12 |              3 |
| Vehicles            |               6 |         8 |              7 |
