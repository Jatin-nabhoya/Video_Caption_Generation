# Experimental strengths & weaknesses (auto-drafted - check and edit)

## CLIP4Clip
- Overall CIDEr: zero-shot 39.4 -> fine-tuned 45.9
- **Strongest classes:** Music & Dance (77), Animals (63)
- **Weakest classes:** Other (32), People & Daily life (34)
- **Main failure reasons:** Object / subject error (31% of failures), Action error (24% of failures)
- Caption style: 7.6 words on average, 2.01 unsupported words per caption, vocabulary 1236 words, 100% copied verbatim from a training caption
- Most sensitive to **ref consensus** (Spearman rho = +0.23)

## GIT
- Overall CIDEr: zero-shot 39.8 -> fine-tuned 101.3
- **Strongest classes:** Music & Dance (218), Vehicles (135)
- **Weakest classes:** Other (9), People & Daily life (63)
- **Main failure reasons:** Action error (48% of failures), Wording only (meaning OK) (18% of failures)
- Caption style: 6.3 words on average, 0.84 unsupported words per caption, vocabulary 392 words, 57% copied verbatim from a training caption
- Most sensitive to **ref consensus** (Spearman rho = +0.31)

## BLIP-2
- Overall CIDEr: zero-shot 49.1 -> fine-tuned 178.3
- **Strongest classes:** Music & Dance (297), Animals (211)
- **Weakest classes:** Other (32), People & Daily life (146)
- **Main failure reasons:** Wording only (meaning OK) (51% of failures), Action error (33% of failures)
- Caption style: 6.5 words on average, 0.27 unsupported words per caption, vocabulary 526 words, 41% copied verbatim from a training caption
- Most sensitive to **ref consensus** (Spearman rho = +0.59)

## Qwen2.5-VL
- Overall CIDEr: zero-shot 81.9 -> fine-tuned 146.9
- **Strongest classes:** Music & Dance (252), Animals (180)
- **Weakest classes:** Other (2), Sports & Exercise (110)
- **Main failure reasons:** Action error (41% of failures), Wording only (meaning OK) (23% of failures)
- Caption style: 6.4 words on average, 0.50 unsupported words per caption, vocabulary 504 words, 42% copied verbatim from a training caption
- Most sensitive to **ref consensus** (Spearman rho = +0.47)
